
function dupa = MISE_PI(k_p, k_i)
    a = 1
    b = 2
    c = 1
    
    sys_ob = tf(1, [a, b, c])
%     sys_reg = pid(k_p,k_i)
    sys_reg = tf(k_p*k_i,[1, 0])
    Ke = tf(1, [1, sys_ob])
    dupa = 1
end